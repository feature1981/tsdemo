"""
Q172. Capture Console Output
"""

def display():
    print("Hello PyTest")


def test_output(capsys):

    display()

    captured = capsys.readouterr()

    assert captured.out.strip() == "Hello PyTest"
