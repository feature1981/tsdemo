"""
Q174. API Response Validation Simulation
"""

def get_response():

    return {
        "status_code": 200,
        "message": "Success"
    }


def test_api_response():

    response = get_response()

    assert response["status_code"] == 200
    assert response["message"] == "Success"
