"""
Q161. Basic PyTest Function

Run:
pytest q161_basic_pytest_function.py -v
"""

def add(a, b):
    return a + b


def test_addition():
    assert add(2, 3) == 5
