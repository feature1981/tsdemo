"""
Q178. PyTest Hook Example

Add inside conftest.py:

def pytest_sessionstart(session):
    print("Session Started")
"""

def test_dummy():

    assert True
