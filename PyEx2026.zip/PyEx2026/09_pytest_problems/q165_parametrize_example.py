"""
Q165. Parametrize Example
"""

import pytest


@pytest.mark.parametrize(
    "a,b,result",
    [
        (1, 2, 3),
        (2, 3, 5),
        (5, 5, 10)
    ]
)
def test_addition(a, b, result):

    assert a + b == result
