"""
Q175. JSON Validation
"""

import json


def test_json_data():

    data = '{"name":"Python","version":3.12}'

    parsed = json.loads(data)

    assert parsed["name"] == "Python"
