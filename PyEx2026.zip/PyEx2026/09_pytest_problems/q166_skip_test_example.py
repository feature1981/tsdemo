"""
Q166. Skip Test Example
"""

import pytest


@pytest.mark.skip(reason="Feature not ready")
def test_payment():
    assert True
