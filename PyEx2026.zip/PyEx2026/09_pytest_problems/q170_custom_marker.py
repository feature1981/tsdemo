"""
Q170. Custom Marker Example

Run:
pytest -m smoke
"""

import pytest


@pytest.mark.smoke
def test_login():

    assert True
