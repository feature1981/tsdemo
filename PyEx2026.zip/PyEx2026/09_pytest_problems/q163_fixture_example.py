"""
Q163. PyTest Fixture Example
"""

import pytest


@pytest.fixture
def sample_data():
    return [1, 2, 3]


def test_list_length(sample_data):
    assert len(sample_data) == 3
