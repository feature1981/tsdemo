"""
Shared Fixtures for PyTest Examples
"""

import pytest


@pytest.fixture
def browser():
    return "Chrome"
