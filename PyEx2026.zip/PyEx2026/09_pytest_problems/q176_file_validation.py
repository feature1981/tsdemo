"""
Q176. File Validation
"""

def test_file_creation(tmp_path):

    file = tmp_path / "report.txt"

    file.write_text("Automation Report")

    assert file.exists()
