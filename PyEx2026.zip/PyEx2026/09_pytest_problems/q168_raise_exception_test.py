"""
Q168. Test Exception Using raises()
"""

import pytest


def divide(a, b):
    return a / b


def test_divide_by_zero():

    with pytest.raises(ZeroDivisionError):
        divide(10, 0)
