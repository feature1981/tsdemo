"""
Q167. xfail Example
"""

import pytest


@pytest.mark.xfail
def test_failure():

    assert 2 == 3
