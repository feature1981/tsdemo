"""
Q177. Database Validation Simulation
"""

def fetch_user():

    return {
        "id": 101,
        "name": "Murugan"
    }


def test_database_record():

    user = fetch_user()

    assert user["id"] == 101
