"""
Q164. Fixture Scope Example
"""

import pytest


@pytest.fixture(scope="module")
def setup_data():
    print("\nSetup Executed")
    return "Python"


def test_case_1(setup_data):
    assert setup_data == "Python"


def test_case_2(setup_data):
    assert len(setup_data) == 6
