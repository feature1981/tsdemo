"""
Q162. PyTest Assertions
"""

def get_status():
    return "PASS"


def test_status():
    assert get_status() == "PASS"
