"""
Q171. Temporary Directory Fixture
"""

def test_temp_file(tmp_path):

    file = tmp_path / "sample.txt"

    file.write_text("PyTest Example")

    content = file.read_text()

    assert content == "PyTest Example"
