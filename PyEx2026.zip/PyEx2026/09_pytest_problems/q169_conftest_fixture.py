"""
Q169. conftest.py Example

Create separate conftest.py:

import pytest

@pytest.fixture
def browser():
    return "Chrome"

Then use fixture directly.
"""

def test_browser(browser):

    assert browser == "Chrome"
