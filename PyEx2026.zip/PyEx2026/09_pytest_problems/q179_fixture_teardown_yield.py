"""
Q179. Fixture Teardown Using yield
"""

import pytest


@pytest.fixture
def setup_teardown():

    print("\nSetup Browser")

    yield "Chrome"

    print("\nClose Browser")


def test_browser(setup_teardown):

    assert setup_teardown == "Chrome"
