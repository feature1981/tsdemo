# Python Mastery - 09 PyTest Problems

This folder contains PyTest practice programs.

## Topics Covered

- Basic tests
- Assertions
- Fixtures
- Fixture scope
- Parametrize
- skip / xfail
- Exception testing
- conftest.py
- Custom markers
- monkeypatch
- capsys
- Hooks
- yield teardown
- Selenium-style fixtures

## Install PyTest

```bash
pip install pytest
```

## Run All Tests

```bash
pytest -v
```

## Run Single File

```bash
pytest q161_basic_pytest_function.py -v
```
