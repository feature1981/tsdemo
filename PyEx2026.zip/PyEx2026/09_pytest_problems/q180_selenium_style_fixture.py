"""
Q180. Selenium-style Driver Fixture
"""

import pytest


class Driver:

    def open(self):
        return "Browser Opened"

    def close(self):
        print("Browser Closed")


@pytest.fixture
def driver():

    driver = Driver()

    yield driver

    driver.close()


def test_open_browser(driver):

    assert driver.open() == "Browser Opened"
