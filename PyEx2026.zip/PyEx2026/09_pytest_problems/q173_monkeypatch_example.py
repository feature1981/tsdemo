"""
Q173. monkeypatch Example
"""

import os


def get_env():
    return os.getenv("ENV")


def test_environment(monkeypatch):

    monkeypatch.setenv("ENV", "QA")

    assert get_env() == "QA"
