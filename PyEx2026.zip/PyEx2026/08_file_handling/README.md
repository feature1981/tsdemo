# Python Mastery - 08 File Handling

This folder contains file handling programs.

## Topics Covered

- Read/Write text files
- Append files
- CSV handling
- JSON handling
- Binary files
- File existence check
- File delete/rename
- Directory listing
- Large file reading
- Merge files

## Run Example

```bash
cd python_mastery/08_file_handling
python q141_read_text_file.py
```
