"""
Q154. Rename File
"""

import os


def rename_file(old_name, new_name):

    os.rename(old_name, new_name)


if __name__ == "__main__":

    with open("old.txt", "w") as file:
        file.write("Rename Me")

    rename_file("old.txt", "new.txt")

    print("File Renamed")
