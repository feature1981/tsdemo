"""
Q146. Count Lines in File
"""

def count_lines(file_path):

    with open(file_path, "r") as file:
        lines = file.readlines()

    return len(lines)


if __name__ == "__main__":

    with open("lines.txt", "w") as file:
        file.write("One\nTwo\nThree")

    result = count_lines("lines.txt")

    print("Line Count:", result)
