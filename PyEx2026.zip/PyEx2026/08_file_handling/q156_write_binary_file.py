"""
Q156. Write Binary File
"""

def write_binary(file_path, data):

    with open(file_path, "wb") as file:
        file.write(data)


if __name__ == "__main__":

    write_binary("data.bin", b"Binary Content")

    print("Binary File Written")
