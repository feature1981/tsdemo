"""
Q149. Write CSV File
"""

import csv


def write_csv(file_path):

    with open(file_path, "w", newline="") as file:

        writer = csv.writer(file)

        writer.writerow(["Name", "Role"])
        writer.writerow(["Murugan", "Architect"])


if __name__ == "__main__":

    write_csv("employees.csv")

    print("CSV Written")
