"""
Q147. Copy File Content
"""

def copy_file(source, destination):

    with open(source, "r") as src:
        content = src.read()

    with open(destination, "w") as dest:
        dest.write(content)


if __name__ == "__main__":

    with open("source.txt", "w") as file:
        file.write("Copy this content")

    copy_file("source.txt", "destination.txt")

    print("File Copied")
