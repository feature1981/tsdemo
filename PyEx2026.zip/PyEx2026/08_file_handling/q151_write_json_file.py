"""
Q151. Write JSON File
"""

import json


def write_json(file_path, data):

    with open(file_path, "w") as file:
        json.dump(data, file, indent=4)


if __name__ == "__main__":

    data = {
        "framework": "PyTest",
        "language": "Python"
    }

    write_json("framework.json", data)

    print("JSON Written")
