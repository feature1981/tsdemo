"""
Q160. Merge Multiple Text Files
"""

def merge_files(file1, file2, output):

    with open(file1, "r") as f1:
        content1 = f1.read()

    with open(file2, "r") as f2:
        content2 = f2.read()

    with open(output, "w") as out:
        out.write(content1)
        out.write("\n")
        out.write(content2)


if __name__ == "__main__":

    with open("file1.txt", "w") as file:
        file.write("First File")

    with open("file2.txt", "w") as file:
        file.write("Second File")

    merge_files("file1.txt", "file2.txt", "merged.txt")

    print("Files Merged")
