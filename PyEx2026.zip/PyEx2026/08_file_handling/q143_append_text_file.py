"""
Q143. Append Content to File
"""

def append_file(file_path, content):

    with open(file_path, "a") as file:
        file.write(content)


if __name__ == "__main__":

    append_file("append.txt", "First Line\n")
    append_file("append.txt", "Second Line\n")

    print("Content Appended")
