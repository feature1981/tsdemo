"""
Q155. Read Binary File
"""

def read_binary(file_path):

    with open(file_path, "rb") as file:

        content = file.read()

    return content


if __name__ == "__main__":

    with open("binary.bin", "wb") as file:
        file.write(b"Python")

    result = read_binary("binary.bin")

    print(result)
