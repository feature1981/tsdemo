"""
Q141. Read Text File
"""

def read_file(file_path):

    with open(file_path, "r") as file:
        content = file.read()

    return content


if __name__ == "__main__":

    sample_file = "sample.txt"

    with open(sample_file, "w") as file:
        file.write("Python File Handling")

    result = read_file(sample_file)

    print(result)
