"""
Q142. Write to Text File
"""

def write_file(file_path, content):

    with open(file_path, "w") as file:
        file.write(content)


if __name__ == "__main__":

    write_file("output.txt", "Hello Python")

    print("Content Written Successfully")
