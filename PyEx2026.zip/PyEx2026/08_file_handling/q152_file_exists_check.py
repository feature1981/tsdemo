"""
Q152. Check if File Exists
"""

import os


def file_exists(file_path):

    return os.path.exists(file_path)


if __name__ == "__main__":

    result = file_exists("sample.txt")

    print("File Exists:", result)
