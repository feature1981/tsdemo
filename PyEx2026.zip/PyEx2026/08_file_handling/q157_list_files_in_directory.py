"""
Q157. List Files in Directory
"""

import os


def list_files(path):

    files = os.listdir(path)

    return files


if __name__ == "__main__":

    result = list_files(".")

    print(result)
