"""
Q145. Count Words in File
"""

def count_words(file_path):

    with open(file_path, "r") as file:
        content = file.read()

    words = content.split()

    return len(words)


if __name__ == "__main__":

    with open("words.txt", "w") as file:
        file.write("Python is easy to learn")

    result = count_words("words.txt")

    print("Word Count:", result)
