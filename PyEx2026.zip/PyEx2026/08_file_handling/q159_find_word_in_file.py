"""
Q159. Search Word in File
"""

def find_word(file_path, target):

    with open(file_path, "r") as file:

        content = file.read()

    return target in content


if __name__ == "__main__":

    with open("search.txt", "w") as file:
        file.write("Python automation framework")

    result = find_word("search.txt", "automation")

    print("Word Found:", result)
