"""
Q144. Read File Line by Line
"""

def read_lines(file_path):

    with open(file_path, "r") as file:

        for line in file:
            print(line.strip())


if __name__ == "__main__":

    with open("sample_lines.txt", "w") as file:
        file.write("Line1\nLine2\nLine3")

    read_lines("sample_lines.txt")
