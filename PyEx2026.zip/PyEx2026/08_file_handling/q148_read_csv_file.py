"""
Q148. Read CSV File
"""

import csv


def read_csv(file_path):

    with open(file_path, "r") as file:

        reader = csv.reader(file)

        for row in reader:
            print(row)


if __name__ == "__main__":

    with open("sample.csv", "w", newline="") as file:

        writer = csv.writer(file)

        writer.writerow(["Name", "Age"])
        writer.writerow(["John", 30])

    read_csv("sample.csv")
