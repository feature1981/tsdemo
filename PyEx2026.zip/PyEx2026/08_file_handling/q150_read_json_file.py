"""
Q150. Read JSON File
"""

import json


def read_json(file_path):

    with open(file_path, "r") as file:

        data = json.load(file)

    return data


if __name__ == "__main__":

    sample_data = {
        "name": "Python",
        "version": 3.12
    }

    with open("sample.json", "w") as file:
        json.dump(sample_data, file)

    result = read_json("sample.json")

    print(result)
