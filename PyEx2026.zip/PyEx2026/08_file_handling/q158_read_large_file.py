"""
Q158. Read Large File Efficiently
"""

def read_large_file(file_path):

    with open(file_path, "r") as file:

        for line in file:
            print(line.strip())


if __name__ == "__main__":

    with open("large.txt", "w") as file:

        for i in range(1, 6):
            file.write(f"Line {i}\n")

    read_large_file("large.txt")
