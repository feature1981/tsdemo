"""
Q153. Delete File
"""

import os


def delete_file(file_path):

    if os.path.exists(file_path):
        os.remove(file_path)
        return "File Deleted"

    return "File Not Found"


if __name__ == "__main__":

    with open("temp.txt", "w") as file:
        file.write("Temporary File")

    result = delete_file("temp.txt")

    print(result)
