# Python Mastery - 01 Basics

This folder contains 20 beginner Python programs.

## How to Run

Open terminal from project root:

```bash
cd python_mastery/01_basics
python q01_reverse_string.py
```

Run any file similarly:

```bash
python q02_palindrome_string.py
python q03_count_vowels.py
```

## Suggested Practice Method

1. Read the question.
2. Run the program.
3. Change input values.
4. Add print statements.
5. Break the code intentionally.
6. Debug and fix it.
7. Rewrite without seeing the answer.

## Topics Covered

- Strings
- Lists
- Loops
- Conditions
- Dictionaries
- Functions
- Basic number logic
