"""
Q80. Access Nested Dictionary Values
"""

def get_employee_role(data, employee):

    return data[employee]["role"]


if __name__ == "__main__":

    employees = {
        "emp1": {
            "name": "John",
            "role": "QA"
        },
        "emp2": {
            "name": "David",
            "role": "Developer"
        }
    }

    result = get_employee_role(employees, "emp2")

    print("Role:", result)
