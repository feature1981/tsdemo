"""
Q61. Create a Dictionary
"""

def create_student():
    student = {
        "name": "Murugan",
        "age": 35,
        "role": "Automation Architect"
    }

    return student


if __name__ == "__main__":

    result = create_student()

    print(result)
