"""
Q79. Convert Two Lists into Dictionary
"""

def lists_to_dict(keys, values):

    return dict(zip(keys, values))


if __name__ == "__main__":

    keys = ["name", "age", "role"]
    values = ["Murugan", 35, "Architect"]

    result = lists_to_dict(keys, values)

    print(result)
