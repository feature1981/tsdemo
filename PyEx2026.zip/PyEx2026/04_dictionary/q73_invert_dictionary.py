"""
Q73. Invert Dictionary

Swap keys and values.
"""

def invert_dictionary(data):

    inverted = {}

    for key, value in data.items():
        inverted[value] = key

    return inverted


if __name__ == "__main__":

    data = {
        "a": 1,
        "b": 2
    }

    result = invert_dictionary(data)

    print(result)
