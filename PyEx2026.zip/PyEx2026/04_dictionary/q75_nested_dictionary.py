"""
Q75. Nested Dictionary Example
"""

def create_nested_dictionary():

    employees = {
        "emp1": {
            "name": "John",
            "role": "QA"
        },
        "emp2": {
            "name": "David",
            "role": "Developer"
        }
    }

    return employees


if __name__ == "__main__":

    result = create_nested_dictionary()

    print(result)
