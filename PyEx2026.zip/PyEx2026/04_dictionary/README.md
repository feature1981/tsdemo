# Python Mastery - 04 Dictionary

This folder contains dictionary-based coding problems.

## Topics Covered

- Dictionary creation
- Merge dictionaries
- Frequency counting
- Sorting dictionaries
- Nested dictionaries
- Dictionary comprehension
- Filtering
- Duplicate values
- Zip and mapping
- Grouping problems

## Run Example

```bash
cd python_mastery/04_dictionary
python q61_create_dictionary.py
```
