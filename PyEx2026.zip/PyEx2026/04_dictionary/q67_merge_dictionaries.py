"""
Q67. Merge Two Dictionaries
"""

def merge_dicts(dict1, dict2):

    merged = dict1.copy()

    merged.update(dict2)

    return merged


if __name__ == "__main__":

    dict1 = {"a": 1, "b": 2}
    dict2 = {"c": 3, "d": 4}

    result = merge_dicts(dict1, dict2)

    print(result)
