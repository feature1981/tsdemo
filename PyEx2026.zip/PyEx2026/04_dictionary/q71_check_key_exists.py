"""
Q71. Check if Key Exists
"""

def key_exists(data, key):

    return key in data


if __name__ == "__main__":

    employee = {
        "id": 101,
        "name": "Murugan"
    }

    result = key_exists(employee, "name")

    print("Key Exists:", result)
