"""
Q74. Group Words by Length
"""

def group_by_length(words):

    grouped = {}

    for word in words:

        length = len(word)

        if length not in grouped:
            grouped[length] = []

        grouped[length].append(word)

    return grouped


if __name__ == "__main__":

    words = ["python", "ai", "automation", "code"]

    result = group_by_length(words)

    print(result)
