"""
Q62. Access Dictionary Values
"""

def access_values(student):

    print("Name :", student["name"])
    print("Age  :", student["age"])


if __name__ == "__main__":

    student = {
        "name": "Python",
        "age": 10
    }

    access_values(student)
