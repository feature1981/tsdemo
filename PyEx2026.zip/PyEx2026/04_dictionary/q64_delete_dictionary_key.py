"""
Q64. Delete Dictionary Key
"""

def delete_key(data, key):

    if key in data:
        del data[key]

    return data


if __name__ == "__main__":

    employee = {
        "id": 101,
        "name": "David",
        "salary": 50000
    }

    result = delete_key(employee, "salary")

    print(result)
