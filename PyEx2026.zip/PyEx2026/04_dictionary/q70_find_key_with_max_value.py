"""
Q70. Find Key with Maximum Value
"""

def max_value_key(data):

    maximum = max(data, key=data.get)

    return maximum


if __name__ == "__main__":

    marks = {
        "math": 90,
        "science": 95,
        "english": 85
    }

    result = max_value_key(marks)

    print("Highest Mark Subject:", result)
