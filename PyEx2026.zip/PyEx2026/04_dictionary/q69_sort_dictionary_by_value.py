"""
Q69. Sort Dictionary by Value
"""

def sort_by_value(data):

    return dict(sorted(data.items(), key=lambda item: item[1]))


if __name__ == "__main__":

    data = {
        "apple": 50,
        "banana": 20,
        "orange": 30
    }

    result = sort_by_value(data)

    print(result)
