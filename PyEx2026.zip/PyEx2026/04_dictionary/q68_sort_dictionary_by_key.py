"""
Q68. Sort Dictionary by Key
"""

def sort_by_key(data):

    return dict(sorted(data.items()))


if __name__ == "__main__":

    data = {
        "d": 4,
        "a": 1,
        "c": 3,
        "b": 2
    }

    result = sort_by_key(data)

    print(result)
