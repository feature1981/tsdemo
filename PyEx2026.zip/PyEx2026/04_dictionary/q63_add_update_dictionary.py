"""
Q63. Add and Update Dictionary Values
"""

def update_dictionary(data):

    data["city"] = "Bangalore"
    data["age"] = 40

    return data


if __name__ == "__main__":

    person = {
        "name": "John",
        "age": 30
    }

    result = update_dictionary(person)

    print(result)
