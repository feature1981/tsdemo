"""
Q78. Find Duplicate Values in Dictionary
"""

def duplicate_values(data):

    duplicates = []

    values = list(data.values())

    for value in values:

        if values.count(value) > 1 and value not in duplicates:
            duplicates.append(value)

    return duplicates


if __name__ == "__main__":

    data = {
        "a": 10,
        "b": 20,
        "c": 10,
        "d": 30
    }

    result = duplicate_values(data)

    print("Duplicate Values:", result)
