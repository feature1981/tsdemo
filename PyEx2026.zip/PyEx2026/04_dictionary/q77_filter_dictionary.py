"""
Q77. Filter Dictionary Values
"""

def filter_dictionary(data):

    filtered = {}

    for key, value in data.items():

        if value > 50:
            filtered[key] = value

    return filtered


if __name__ == "__main__":

    marks = {
        "math": 90,
        "science": 45,
        "english": 70
    }

    result = filter_dictionary(marks)

    print(result)
