"""
Q72. Dictionary Comprehension
"""

def square_numbers():

    squares = {x: x * x for x in range(1, 6)}

    return squares


if __name__ == "__main__":

    result = square_numbers()

    print(result)
