"""
Q65. Count Character Frequency Using Dictionary
"""

def character_frequency(text):

    frequency = {}

    for char in text:

        if char in frequency:
            frequency[char] += 1
        else:
            frequency[char] = 1

    return frequency


if __name__ == "__main__":

    text = "automation"

    result = character_frequency(text)

    print(result)
