"""
Q76. Sum of Dictionary Values
"""

def sum_values(data):

    total = sum(data.values())

    return total


if __name__ == "__main__":

    expenses = {
        "food": 200,
        "travel": 300,
        "shopping": 500
    }

    result = sum_values(expenses)

    print("Total:", result)
