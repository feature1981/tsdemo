"""
Q105. Reverse String Using Recursion
"""

def reverse_string(text):

    if len(text) == 0:
        return text

    return reverse_string(text[1:]) + text[0]


if __name__ == "__main__":

    text = "python"

    result = reverse_string(text)

    print("Reversed:", result)
