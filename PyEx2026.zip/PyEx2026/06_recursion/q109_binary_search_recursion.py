"""
Q109. Binary Search Using Recursion
"""

def binary_search(numbers, target, left, right):

    if left > right:
        return -1

    middle = (left + right) // 2

    if numbers[middle] == target:
        return middle

    elif target < numbers[middle]:
        return binary_search(numbers, target, left, middle - 1)

    else:
        return binary_search(numbers, target, middle + 1, right)


if __name__ == "__main__":

    numbers = [1, 2, 3, 4, 5, 6, 7]
    target = 5

    result = binary_search(numbers, target, 0, len(numbers) - 1)

    print("Index:", result)
