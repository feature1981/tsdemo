"""
Q119. Flatten Nested List Using Recursion
"""

def flatten(items):

    result = []

    for item in items:

        if isinstance(item, list):
            result.extend(flatten(item))
        else:
            result.append(item)

    return result


if __name__ == "__main__":

    nested = [1, [2, [3, 4]], 5]

    result = flatten(nested)

    print("Flattened:", result)
