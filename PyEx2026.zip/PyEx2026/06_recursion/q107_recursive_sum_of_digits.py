"""
Q107. Sum of Digits Using Recursion
"""

def sum_digits(number):

    if number == 0:
        return 0

    return number % 10 + sum_digits(number // 10)


if __name__ == "__main__":

    number = 1234

    result = sum_digits(number)

    print("Sum of Digits:", result)
