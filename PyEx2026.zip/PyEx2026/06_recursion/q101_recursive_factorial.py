"""
Q101. Recursive Factorial

5! = 5 * 4 * 3 * 2 * 1
"""

def factorial(number):

    if number == 0 or number == 1:
        return 1

    return number * factorial(number - 1)


if __name__ == "__main__":

    number = 5

    result = factorial(number)

    print("Factorial:", result)
