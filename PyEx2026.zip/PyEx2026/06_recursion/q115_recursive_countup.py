"""
Q115. Recursive Countup
"""

def countup(number):

    if number == 0:
        return

    countup(number - 1)

    print(number)


if __name__ == "__main__":

    countup(5)
