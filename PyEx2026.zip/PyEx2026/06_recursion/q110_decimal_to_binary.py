"""
Q110. Decimal to Binary Using Recursion
"""

def decimal_to_binary(number):

    if number == 0:
        return ""

    return decimal_to_binary(number // 2) + str(number % 2)


if __name__ == "__main__":

    number = 10

    result = decimal_to_binary(number)

    print("Binary:", result)
