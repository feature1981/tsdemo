"""
Q103. Sum of Natural Numbers Using Recursion
"""

def natural_sum(number):

    if number == 1:
        return 1

    return number + natural_sum(number - 1)


if __name__ == "__main__":

    number = 5

    result = natural_sum(number)

    print("Sum:", result)
