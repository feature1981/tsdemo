"""
Q120. Recursive File Search Simulation
"""

mock_files = {
    "root": {
        "docs": {
            "resume.txt": None,
            "notes.txt": None
        },
        "images": {
            "photo.png": None
        }
    }
}


def search_file(folder, target):

    for name, content in folder.items():

        if name == target:
            return True

        if isinstance(content, dict):

            if search_file(content, target):
                return True

    return False


if __name__ == "__main__":

    result = search_file(mock_files, "photo.png")

    print("File Found:", result)
