"""
Q113. Tower of Hanoi
"""

def tower_of_hanoi(disks, source, destination, auxiliary):

    if disks == 1:
        print(f"Move disk 1 from {source} to {destination}")
        return

    tower_of_hanoi(disks - 1, source, auxiliary, destination)

    print(f"Move disk {disks} from {source} to {destination}")

    tower_of_hanoi(disks - 1, auxiliary, destination, source)


if __name__ == "__main__":

    tower_of_hanoi(3, "A", "C", "B")
