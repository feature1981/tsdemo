"""
Q112. Find Maximum Number Using Recursion
"""

def find_max(numbers):

    if len(numbers) == 1:
        return numbers[0]

    maximum = find_max(numbers[1:])

    if numbers[0] > maximum:
        return numbers[0]

    return maximum


if __name__ == "__main__":

    numbers = [10, 50, 20, 80, 30]

    result = find_max(numbers)

    print("Maximum:", result)
