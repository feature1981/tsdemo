"""
Q116. Multiply Numbers Using Recursion
"""

def multiply(a, b):

    if b == 0:
        return 0

    return a + multiply(a, b - 1)


if __name__ == "__main__":

    result = multiply(5, 3)

    print("Multiplication:", result)
