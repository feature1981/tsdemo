"""
Q106. Palindrome Check Using Recursion
"""

def palindrome(text):

    if len(text) <= 1:
        return True

    if text[0] != text[-1]:
        return False

    return palindrome(text[1:-1])


if __name__ == "__main__":

    text = "madam"

    result = palindrome(text)

    print("Palindrome:", result)
