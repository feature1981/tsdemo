"""
Q118. Count Character Occurrences Using Recursion
"""

def count_occurrences(text, target):

    if text == "":
        return 0

    if text[0] == target:
        return 1 + count_occurrences(text[1:], target)

    return count_occurrences(text[1:], target)


if __name__ == "__main__":

    text = "banana"

    result = count_occurrences(text, "a")

    print("Occurrences:", result)
