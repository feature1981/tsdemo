"""
Q104. Find Power Using Recursion

Example:
2^3 = 8
"""

def power(base, exponent):

    if exponent == 0:
        return 1

    return base * power(base, exponent - 1)


if __name__ == "__main__":

    result = power(2, 3)

    print("Power:", result)
