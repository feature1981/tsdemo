"""
Q114. Recursive Countdown
"""

def countdown(number):

    if number == 0:
        print("Done")
        return

    print(number)

    countdown(number - 1)


if __name__ == "__main__":

    countdown(5)
