"""
Q111. Sum of List Elements Using Recursion
"""

def list_sum(numbers):

    if len(numbers) == 0:
        return 0

    return numbers[0] + list_sum(numbers[1:])


if __name__ == "__main__":

    numbers = [1, 2, 3, 4, 5]

    result = list_sum(numbers)

    print("Sum:", result)
