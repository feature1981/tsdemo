"""
Q108. Greatest Common Divisor Using Recursion
"""

def gcd(a, b):

    if b == 0:
        return a

    return gcd(b, a % b)


if __name__ == "__main__":

    result = gcd(48, 18)

    print("GCD:", result)
