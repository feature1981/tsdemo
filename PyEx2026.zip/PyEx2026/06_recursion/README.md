# Python Mastery - 06 Recursion

This folder contains recursion-based coding problems.

## Topics Covered

- Recursive factorial
- Fibonacci
- Binary search
- GCD
- Palindrome
- String reversal
- Tower of Hanoi
- Recursive flattening
- Recursive traversal
- Recursive counting

## Run Example

```bash
cd python_mastery/06_recursion
python q101_recursive_factorial.py
```
