"""
Q117. Find String Length Using Recursion
"""

def string_length(text):

    if text == "":
        return 0

    return 1 + string_length(text[1:])


if __name__ == "__main__":

    text = "python"

    result = string_length(text)

    print("Length:", result)
