"""
Q129. Multilevel Inheritance
"""

class Grandparent:

    def house(self):
        print("Grandparent House")


class Parent(Grandparent):

    def car(self):
        print("Parent Car")


class Child(Parent):

    def bike(self):
        print("Child Bike")


if __name__ == "__main__":

    child = Child()

    child.house()
    child.car()
    child.bike()
