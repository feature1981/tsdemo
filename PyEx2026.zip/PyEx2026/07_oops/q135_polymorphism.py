"""
Q135. Polymorphism Example
"""

class Dog:

    def sound(self):
        print("Dog Bark")


class Cat:

    def sound(self):
        print("Cat Meow")


def animal_sound(animal):
    animal.sound()


if __name__ == "__main__":

    dog = Dog()
    cat = Cat()

    animal_sound(dog)
    animal_sound(cat)
