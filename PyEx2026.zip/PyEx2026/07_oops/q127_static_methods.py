"""
Q127. Static Methods
"""

class MathUtility:

    @staticmethod
    def square(number):
        return number * number


if __name__ == "__main__":

    result = MathUtility.square(5)

    print("Square:", result)
