"""
Q124. Class Variables
"""

class Employee:

    company = "OpenAI"

    def __init__(self, name):
        self.name = name

    def display(self):
        print(self.name, Employee.company)


if __name__ == "__main__":

    e1 = Employee("John")
    e2 = Employee("David")

    e1.display()
    e2.display()
