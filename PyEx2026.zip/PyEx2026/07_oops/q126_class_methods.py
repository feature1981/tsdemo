"""
Q126. Class Methods
"""

class Employee:

    company = "AI Corp"

    @classmethod
    def change_company(cls, new_name):
        cls.company = new_name


if __name__ == "__main__":

    print("Before:", Employee.company)

    Employee.change_company("OpenAI")

    print("After :", Employee.company)
