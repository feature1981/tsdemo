"""
Q133. Encapsulation Example
"""

class BankAccount:

    def __init__(self):
        self.__balance = 1000

    def deposit(self, amount):
        self.__balance += amount

    def get_balance(self):
        return self.__balance


if __name__ == "__main__":

    account = BankAccount()

    account.deposit(500)

    print("Balance:", account.get_balance())
