"""
Q128. Single Inheritance
"""

class Animal:

    def sound(self):
        print("Animal makes sound")


class Dog(Animal):

    def bark(self):
        print("Dog barks")


if __name__ == "__main__":

    dog = Dog()

    dog.sound()
    dog.bark()
