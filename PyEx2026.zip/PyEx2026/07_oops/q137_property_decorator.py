"""
Q137. @property Decorator
"""

class Student:

    def __init__(self, marks):
        self._marks = marks

    @property
    def marks(self):
        return self._marks


if __name__ == "__main__":

    student = Student(95)

    print("Marks:", student.marks)
