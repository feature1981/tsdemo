"""
Q140. Dunder Methods (__str__)
"""

class Employee:

    def __init__(self, name):
        self.name = name

    def __str__(self):
        return f"Employee Name: {self.name}"


if __name__ == "__main__":

    employee = Employee("Murugan")

    print(employee)
