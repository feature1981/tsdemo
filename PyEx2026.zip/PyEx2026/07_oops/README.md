# Python Mastery - 07 OOPS

This folder contains Object-Oriented Programming examples.

## Topics Covered

- Classes & Objects
- Constructors
- Instance/Class Variables
- Instance/Class/Static Methods
- Inheritance
- Method Overriding
- Encapsulation
- Abstraction
- Polymorphism
- Composition
- Singleton Pattern
- Dunder Methods

## Run Example

```bash
cd python_mastery/07_oops
python q121_create_class_and_object.py
```
