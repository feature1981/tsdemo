"""
Q138. Singleton Pattern
"""

class Singleton:

    _instance = None

    def __new__(cls):

        if cls._instance is None:
            cls._instance = super().__new__(cls)

        return cls._instance


if __name__ == "__main__":

    obj1 = Singleton()
    obj2 = Singleton()

    print(obj1 is obj2)
