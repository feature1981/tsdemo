"""
Q130. Multiple Inheritance
"""

class Father:

    def skills(self):
        print("Driving")


class Mother:

    def talents(self):
        print("Cooking")


class Child(Father, Mother):

    pass


if __name__ == "__main__":

    child = Child()

    child.skills()
    child.talents()
