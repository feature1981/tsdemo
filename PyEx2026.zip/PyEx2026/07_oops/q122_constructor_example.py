"""
Q122. Constructor (__init__) Example
"""

class Car:

    def __init__(self, brand, model):
        self.brand = brand
        self.model = model

    def show(self):
        print(self.brand, self.model)


if __name__ == "__main__":

    car = Car("Toyota", "Camry")

    car.show()
