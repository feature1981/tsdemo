"""
Q134. Abstraction Example
"""

from abc import ABC, abstractmethod


class Vehicle(ABC):

    @abstractmethod
    def start(self):
        pass


class Car(Vehicle):

    def start(self):
        print("Car Started")


if __name__ == "__main__":

    car = Car()

    car.start()
