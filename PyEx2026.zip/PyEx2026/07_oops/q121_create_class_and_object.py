"""
Q121. Create Class and Object
"""

class Employee:

    def __init__(self, name, role):
        self.name = name
        self.role = role

    def display(self):
        print("Name:", self.name)
        print("Role:", self.role)


if __name__ == "__main__":

    emp = Employee("Murugan", "Automation Architect")

    emp.display()
