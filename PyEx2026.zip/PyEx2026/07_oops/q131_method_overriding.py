"""
Q131. Method Overriding
"""

class Animal:

    def sound(self):
        print("Animal Sound")


class Dog(Animal):

    def sound(self):
        print("Dog Bark")


if __name__ == "__main__":

    dog = Dog()

    dog.sound()
