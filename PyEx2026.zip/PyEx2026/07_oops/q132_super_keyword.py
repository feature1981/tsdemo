"""
Q132. super() Keyword
"""

class Parent:

    def __init__(self):
        print("Parent Constructor")


class Child(Parent):

    def __init__(self):
        super().__init__()
        print("Child Constructor")


if __name__ == "__main__":

    child = Child()
