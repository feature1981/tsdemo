"""
Q123. Instance Variables
"""

class Student:

    def __init__(self, name, marks):
        self.name = name
        self.marks = marks

    def display(self):
        print(self.name, self.marks)


if __name__ == "__main__":

    s1 = Student("John", 90)
    s2 = Student("David", 85)

    s1.display()
    s2.display()
