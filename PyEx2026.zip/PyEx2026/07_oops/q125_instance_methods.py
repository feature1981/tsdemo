"""
Q125. Instance Methods
"""

class Calculator:

    def add(self, a, b):
        return a + b


if __name__ == "__main__":

    calc = Calculator()

    result = calc.add(10, 20)

    print("Addition:", result)
