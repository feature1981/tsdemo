# Python Mastery - 03 Lists

This folder contains list and array-based coding problems.

## Topics Covered

- Two Sum
- Sliding Window
- Rotation
- Intersection & Union
- Chunking
- Flattening
- Missing Number
- Maximum Difference
- Duplicate Handling
- Pair Problems

## Run Example

```bash
cd python_mastery/03_lists
python q41_merge_two_lists.py
```
