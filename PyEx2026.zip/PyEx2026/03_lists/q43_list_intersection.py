"""
Q43. Find Common Elements Between Two Lists
"""

def list_intersection(list1, list2):
    return list(set(list1) & set(list2))


if __name__ == "__main__":
    list1 = [1, 2, 3, 4]
    list2 = [3, 4, 5, 6]

    result = list_intersection(list1, list2)

    print("Common Elements:", result)
