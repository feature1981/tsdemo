"""
Q53. Find Pair with Given Sum
"""

def pair_with_sum(numbers, target):

    pairs = []

    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):

            if numbers[i] + numbers[j] == target:
                pairs.append((numbers[i], numbers[j]))

    return pairs


if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]
    target = 5

    result = pair_with_sum(numbers, target)

    print("Pairs:", result)
