"""
Q46. Two Sum Problem

Find two numbers whose sum equals target.
"""

def two_sum(numbers, target):

    for i in range(len(numbers)):
        for j in range(i + 1, len(numbers)):

            if numbers[i] + numbers[j] == target:
                return numbers[i], numbers[j]

    return None


if __name__ == "__main__":
    numbers = [2, 7, 11, 15]
    target = 9

    result = two_sum(numbers, target)

    print("Result:", result)
