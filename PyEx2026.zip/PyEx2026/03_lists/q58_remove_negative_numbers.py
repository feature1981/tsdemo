"""
Q58. Remove Negative Numbers
"""

def remove_negatives(numbers):

    return [num for num in numbers if num >= 0]


if __name__ == "__main__":
    numbers = [-1, 2, -3, 4, 5]

    result = remove_negatives(numbers)

    print("Result:", result)
