"""
Q50. Reverse a List
"""

def reverse_list(numbers):
    return numbers[::-1]


if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]

    result = reverse_list(numbers)

    print("Reversed List:", result)
