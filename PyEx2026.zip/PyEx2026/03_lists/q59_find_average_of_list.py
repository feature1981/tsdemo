"""
Q59. Find Average of List
"""

def find_average(numbers):

    total = sum(numbers)

    return total / len(numbers)


if __name__ == "__main__":
    numbers = [10, 20, 30, 40]

    result = find_average(numbers)

    print("Average:", result)
