"""
Q42. Find Duplicate Elements in List
"""

def find_duplicates(numbers):
    duplicates = []

    for num in numbers:
        if numbers.count(num) > 1 and num not in duplicates:
            duplicates.append(num)

    return duplicates


if __name__ == "__main__":
    numbers = [1, 2, 3, 2, 4, 5, 1]

    result = find_duplicates(numbers)

    print("Duplicates:", result)
