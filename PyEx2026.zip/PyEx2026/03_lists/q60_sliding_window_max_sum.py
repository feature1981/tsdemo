"""
Q60. Sliding Window Maximum Sum

Find maximum sum of subarray of size k.
"""

def max_sum_subarray(numbers, k):

    maximum_sum = 0

    for i in range(len(numbers) - k + 1):

        current_sum = sum(numbers[i:i + k])

        if current_sum > maximum_sum:
            maximum_sum = current_sum

    return maximum_sum


if __name__ == "__main__":
    numbers = [2, 1, 5, 1, 3, 2]
    k = 3

    result = max_sum_subarray(numbers, k)

    print("Maximum Sum:", result)
