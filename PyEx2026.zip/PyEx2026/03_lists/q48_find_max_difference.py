"""
Q48. Find Maximum Difference

Find largest difference between two elements.
"""

def max_difference(numbers):

    minimum = numbers[0]
    maximum_diff = 0

    for num in numbers:

        if num < minimum:
            minimum = num

        difference = num - minimum

        if difference > maximum_diff:
            maximum_diff = difference

    return maximum_diff


if __name__ == "__main__":
    numbers = [7, 1, 5, 3, 6, 4]

    result = max_difference(numbers)

    print("Maximum Difference:", result)
