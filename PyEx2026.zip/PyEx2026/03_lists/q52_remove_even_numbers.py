"""
Q52. Remove Even Numbers from List
"""

def remove_even(numbers):

    result = []

    for num in numbers:
        if num % 2 != 0:
            result.append(num)

    return result


if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5, 6]

    result = remove_even(numbers)

    print("Result:", result)
