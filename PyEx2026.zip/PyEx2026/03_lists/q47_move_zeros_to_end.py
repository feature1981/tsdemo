"""
Q47. Move All Zeros to End
"""

def move_zeros(numbers):

    non_zeros = [num for num in numbers if num != 0]
    zeros = [num for num in numbers if num == 0]

    return non_zeros + zeros


if __name__ == "__main__":
    numbers = [0, 1, 0, 3, 12]

    result = move_zeros(numbers)

    print("Result:", result)
