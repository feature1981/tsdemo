"""
Q56. Flatten Nested List
"""

def flatten_list(nested_list):

    flattened = []

    for sublist in nested_list:
        for item in sublist:
            flattened.append(item)

    return flattened


if __name__ == "__main__":
    nested = [[1, 2], [3, 4], [5, 6]]

    result = flatten_list(nested)

    print("Flattened List:", result)
