"""
Q55. Split List into Chunks
"""

def chunk_list(numbers, chunk_size):

    chunks = []

    for i in range(0, len(numbers), chunk_size):
        chunks.append(numbers[i:i + chunk_size])

    return chunks


if __name__ == "__main__":
    numbers = [1,2,3,4,5,6,7,8]

    result = chunk_list(numbers, 3)

    print("Chunks:", result)
