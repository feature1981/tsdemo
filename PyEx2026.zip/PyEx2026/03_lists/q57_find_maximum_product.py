"""
Q57. Find Maximum Product of Two Numbers
"""

def max_product(numbers):

    numbers.sort()

    return numbers[-1] * numbers[-2]


if __name__ == "__main__":
    numbers = [1, 10, 2, 6, 5]

    result = max_product(numbers)

    print("Maximum Product:", result)
