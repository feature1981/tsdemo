"""
Q54. Find Union of Two Lists
"""

def list_union(list1, list2):
    return list(set(list1) | set(list2))


if __name__ == "__main__":
    list1 = [1, 2, 3]
    list2 = [3, 4, 5]

    result = list_union(list1, list2)

    print("Union:", result)
