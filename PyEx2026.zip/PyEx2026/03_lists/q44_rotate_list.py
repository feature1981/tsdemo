"""
Q44. Rotate List to Right

Example:
[1,2,3,4,5]
Rotate by 2
Output:
[4,5,1,2,3]
"""

def rotate_list(numbers, positions):
    positions = positions % len(numbers)

    return numbers[-positions:] + numbers[:-positions]


if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]

    result = rotate_list(numbers, 2)

    print("Rotated List:", result)
