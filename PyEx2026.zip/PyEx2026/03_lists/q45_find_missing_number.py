"""
Q45. Find Missing Number in Sequence

Example:
[1,2,3,5]
Missing = 4
"""

def find_missing(numbers):
    n = len(numbers) + 1

    expected_sum = n * (n + 1) // 2
    actual_sum = sum(numbers)

    return expected_sum - actual_sum


if __name__ == "__main__":
    numbers = [1, 2, 3, 5]

    result = find_missing(numbers)

    print("Missing Number:", result)
