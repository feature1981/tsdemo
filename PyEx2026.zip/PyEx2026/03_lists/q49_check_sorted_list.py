"""
Q49. Check if List is Sorted
"""

def is_sorted(numbers):

    for i in range(len(numbers) - 1):

        if numbers[i] > numbers[i + 1]:
            return False

    return True


if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5]

    result = is_sorted(numbers)

    print("Is Sorted:", result)
