"""
Q51. Find Second Smallest Number
"""

def second_smallest(numbers):

    unique_numbers = list(set(numbers))
    unique_numbers.sort()

    return unique_numbers[1]


if __name__ == "__main__":
    numbers = [5, 2, 8, 1, 3]

    result = second_smallest(numbers)

    print("Second Smallest:", result)
