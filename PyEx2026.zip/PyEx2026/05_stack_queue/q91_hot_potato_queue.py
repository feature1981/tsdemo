"""
Q91. Hot Potato Game Using Queue
"""

from collections import deque

players = deque(["A", "B", "C", "D", "E"])

while len(players) > 1:

    players.rotate(-1)

    removed = players.popleft()

    print("Removed:", removed)

print("Winner:", players[0])
