"""
Q90. Undo Operation Using Stack
"""

actions = []

actions.append("Type A")
actions.append("Type B")
actions.append("Delete C")

print("Actions:", actions)

undo = actions.pop()

print("Undo Action:", undo)
print("Remaining Actions:", actions)
