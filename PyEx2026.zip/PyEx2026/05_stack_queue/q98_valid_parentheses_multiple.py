"""
Q98. Valid Parentheses with Multiple Types

Supports:
(), {}, []
"""

def valid_parentheses(expression):

    stack = []

    mapping = {
        ")": "(",
        "}": "{",
        "]": "["
    }

    for char in expression:

        if char in "({[":
            stack.append(char)

        elif char in ")}]":

            if not stack or stack[-1] != mapping[char]:
                return False

            stack.pop()

    return len(stack) == 0


if __name__ == "__main__":

    expression = "{[()]}"

    result = valid_parentheses(expression)

    print("Valid:", result)
