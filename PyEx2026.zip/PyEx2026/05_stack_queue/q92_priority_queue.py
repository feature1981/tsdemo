"""
Q92. Priority Queue Example
"""

import heapq

numbers = []

heapq.heappush(numbers, 30)
heapq.heappush(numbers, 10)
heapq.heappush(numbers, 20)

print("Priority Queue:", numbers)

smallest = heapq.heappop(numbers)

print("Removed Smallest:", smallest)
print("Final Queue:", numbers)
