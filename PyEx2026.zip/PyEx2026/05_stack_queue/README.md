# Python Mastery - 05 Stack Queue

This folder contains stack and queue coding problems.

## Topics Covered

- Stack Implementation
- Queue Implementation
- Balanced Parentheses
- Next Greater Element
- Stock Span Problem
- Browser Navigation
- Undo Operation
- Priority Queue
- Circular Queue
- Queue Using Two Stacks

## Run Example

```bash
cd python_mastery/05_stack_queue
python q81_stack_using_list.py
```
