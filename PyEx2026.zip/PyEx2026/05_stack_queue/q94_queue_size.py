"""
Q94. Find Queue Size
"""

from collections import deque

queue = deque([1, 2, 3, 4])

size = len(queue)

print("Queue:", queue)
print("Size:", size)
