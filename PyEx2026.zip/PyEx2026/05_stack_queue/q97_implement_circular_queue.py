"""
Q97. Circular Queue Simulation
"""

queue = [None] * 5

front = 0
rear = 0

queue[rear] = 10
rear = (rear + 1) % 5

queue[rear] = 20
rear = (rear + 1) % 5

print("Circular Queue:", queue)
