"""
Q88. Next Greater Element

Interview-important stack concept.
"""

def next_greater(numbers):

    result = [-1] * len(numbers)

    stack = []

    for i in range(len(numbers)):

        while stack and numbers[i] > numbers[stack[-1]]:

            index = stack.pop()

            result[index] = numbers[i]

        stack.append(i)

    return result


if __name__ == "__main__":

    numbers = [4, 5, 2, 10]

    result = next_greater(numbers)

    print("Numbers:", numbers)
    print("Next Greater:", result)
