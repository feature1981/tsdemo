"""
Q96. Reverse Queue
"""

from collections import deque

queue = deque([1, 2, 3, 4])

reversed_queue = deque(reversed(queue))

print("Original Queue:", queue)
print("Reversed Queue:", reversed_queue)
