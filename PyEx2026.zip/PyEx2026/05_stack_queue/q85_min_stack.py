"""
Q85. Find Minimum Element in Stack
"""

stack = [10, 5, 20, 2, 15]

minimum = min(stack)

print("Stack:", stack)
print("Minimum Element:", minimum)
