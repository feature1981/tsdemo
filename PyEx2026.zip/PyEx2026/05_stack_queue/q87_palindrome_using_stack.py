"""
Q87. Check Palindrome Using Stack
"""

def palindrome_stack(text):

    stack = []

    for char in text:
        stack.append(char)

    reversed_text = ""

    while stack:
        reversed_text += stack.pop()

    return text == reversed_text


if __name__ == "__main__":

    text = "madam"

    result = palindrome_stack(text)

    print("Palindrome:", result)
