"""
Q93. Find Stack Size
"""

stack = [10, 20, 30, 40]

size = len(stack)

print("Stack:", stack)
print("Size:", size)
