"""
Q95. Sort Stack
"""

stack = [30, 10, 50, 20]

stack.sort()

print("Sorted Stack:", stack)
