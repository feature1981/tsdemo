"""
Q100. Queue Using Two Stacks
"""

stack1 = []
stack2 = []

stack1.append(10)
stack1.append(20)
stack1.append(30)

while stack1:
    stack2.append(stack1.pop())

removed = stack2.pop()

print("Removed Element:", removed)

while stack2:
    stack1.append(stack2.pop())

print("Final Queue:", stack1)
