"""
Q83. Check Balanced Parentheses

Interview-important stack problem.
"""

def is_balanced(expression):

    stack = []

    for char in expression:

        if char == "(":
            stack.append(char)

        elif char == ")":

            if not stack:
                return False

            stack.pop()

    return len(stack) == 0


if __name__ == "__main__":

    expression = "(())()"

    result = is_balanced(expression)

    print("Balanced:", result)
