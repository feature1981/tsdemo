"""
Q82. Implement Queue Using List

Queue follows FIFO:
First In First Out
"""

queue = []

queue.append(10)
queue.append(20)
queue.append(30)

print("Queue After Insert:", queue)

removed = queue.pop(0)

print("Removed Element:", removed)
print("Final Queue:", queue)
