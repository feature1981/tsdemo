"""
Q89. Browser Back Navigation Using Stack
"""

back_stack = []

back_stack.append("google.com")
back_stack.append("youtube.com")
back_stack.append("openai.com")

print("Current Stack:", back_stack)

previous_page = back_stack.pop()

print("Going Back From:", previous_page)
print("Current Page:", back_stack[-1])
