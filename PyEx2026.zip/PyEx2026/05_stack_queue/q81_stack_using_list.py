"""
Q81. Implement Stack Using List

Stack follows LIFO:
Last In First Out
"""

stack = []

stack.append(10)
stack.append(20)
stack.append(30)

print("Stack After Push:", stack)

removed = stack.pop()

print("Popped Element:", removed)
print("Final Stack:", stack)
