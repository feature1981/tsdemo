"""
Q3. Count Vowels in a String

Vowels: a, e, i, o, u
"""

def count_vowels(text):
    vowels = "aeiouAEIOU"
    count = 0

    for char in text:
        if char in vowels:
            count += 1

    return count


if __name__ == "__main__":
    input_text = "automation"
    result = count_vowels(input_text)

    print("Input :", input_text)
    print("Vowels:", result)
