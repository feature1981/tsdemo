"""
Q11. Count Frequency of Each Character

Dictionary is used to store character count.
"""

def character_frequency(text):
    frequency = {}

    for char in text:
        if char in frequency:
            frequency[char] += 1
        else:
            frequency[char] = 1

    return frequency


if __name__ == "__main__":
    input_text = "banana"
    result = character_frequency(input_text)

    print("Input:", input_text)
    print("Frequency:", result)
