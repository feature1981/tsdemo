"""
Q14. Find Factorial of a Number

Factorial:
5! = 5 * 4 * 3 * 2 * 1 = 120
"""

def factorial(number):
    result = 1

    for i in range(1, number + 1):
        result *= i

    return result


if __name__ == "__main__":
    number = 5
    result = factorial(number)

    print("Number:", number)
    print("Factorial:", result)
