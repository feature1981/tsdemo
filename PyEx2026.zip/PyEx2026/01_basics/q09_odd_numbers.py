"""
Q9. Find Odd Numbers from a List

A number is odd if num % 2 != 0.
"""

def get_odd_numbers(numbers):
    odd_numbers = []

    for num in numbers:
        if num % 2 != 0:
            odd_numbers.append(num)

    return odd_numbers


if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5, 6]
    result = get_odd_numbers(numbers)

    print("Numbers:", numbers)
    print("Odd Numbers:", result)
