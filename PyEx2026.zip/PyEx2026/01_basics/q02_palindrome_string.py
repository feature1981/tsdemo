"""
Q2. Check Palindrome String

A string is palindrome if original and reversed string are same.
Example: madam, level, radar
"""

def is_palindrome(text):
    return text == text[::-1]


if __name__ == "__main__":
    input_text = "madam"

    if is_palindrome(input_text):
        print("Palindrome")
    else:
        print("Not Palindrome")
