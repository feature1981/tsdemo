"""
Q17. Swap Two Numbers

Python supports direct tuple unpacking.
"""

def swap_numbers(a, b):
    a, b = b, a
    return a, b


if __name__ == "__main__":
    a = 10
    b = 20

    print("Before Swap:")
    print("a =", a)
    print("b =", b)

    a, b = swap_numbers(a, b)

    print("After Swap:")
    print("a =", a)
    print("b =", b)
