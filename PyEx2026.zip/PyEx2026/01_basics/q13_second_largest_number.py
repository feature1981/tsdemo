"""
Q13. Find Second Largest Number

Interview-important problem.
"""

def find_second_largest(numbers):
    unique_numbers = list(set(numbers))
    unique_numbers.sort(reverse=True)

    if len(unique_numbers) < 2:
        return None

    return unique_numbers[1]


if __name__ == "__main__":
    numbers = [10, 25, 5, 80, 30, 80]
    result = find_second_largest(numbers)

    print("Numbers:", numbers)
    print("Second Largest:", result)
