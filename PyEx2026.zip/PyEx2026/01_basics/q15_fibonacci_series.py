"""
Q15. Generate Fibonacci Series

Pattern:
0, 1, 1, 2, 3, 5, 8
"""

def fibonacci_series(count):
    first = 0
    second = 1
    result = []

    for _ in range(count):
        result.append(first)
        first, second = second, first + second

    return result


if __name__ == "__main__":
    count = 10
    result = fibonacci_series(count)

    print("Count:", count)
    print("Fibonacci Series:", result)
