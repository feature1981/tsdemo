"""
Q20. Reverse Words in a Sentence

Example:
Input : Python is easy
Output: easy is Python
"""

def reverse_words(sentence):
    words = sentence.split()
    reversed_words = words[::-1]
    return " ".join(reversed_words)


if __name__ == "__main__":
    sentence = "Python is easy"
    result = reverse_words(sentence)

    print("Input :", sentence)
    print("Output:", result)
