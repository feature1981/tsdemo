"""
Q10. Remove Duplicates from List

Preserves original order.
"""

def remove_duplicates(numbers):
    unique_numbers = []

    for num in numbers:
        if num not in unique_numbers:
            unique_numbers.append(num)

    return unique_numbers


if __name__ == "__main__":
    numbers = [1, 2, 2, 3, 4, 4, 5]
    result = remove_duplicates(numbers)

    print("Original:", numbers)
    print("Unique  :", result)
