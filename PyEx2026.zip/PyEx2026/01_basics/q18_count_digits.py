"""
Q18. Count Digits in a Number

Convert number to string and count length.
"""

def count_digits(number):
    return len(str(abs(number)))


if __name__ == "__main__":
    number = 12345
    result = count_digits(number)

    print("Number:", number)
    print("Digit Count:", result)
