"""
Q16. Check Prime Number

Prime number has only two factors:
1 and itself.
"""

def is_prime(number):
    if number <= 1:
        return False

    for i in range(2, number):
        if number % i == 0:
            return False

    return True


if __name__ == "__main__":
    number = 17

    if is_prime(number):
        print(number, "is Prime")
    else:
        print(number, "is Not Prime")
