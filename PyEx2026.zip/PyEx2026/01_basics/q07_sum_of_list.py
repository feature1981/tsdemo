"""
Q7. Find Sum of List Elements

Do not use sum() initially.
Understand loop-based accumulation.
"""

def find_sum(numbers):
    total = 0

    for num in numbers:
        total += num

    return total


if __name__ == "__main__":
    numbers = [10, 20, 30, 40]
    result = find_sum(numbers)

    print("Numbers:", numbers)
    print("Sum:", result)
