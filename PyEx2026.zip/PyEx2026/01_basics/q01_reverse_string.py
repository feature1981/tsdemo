"""
Q1. Reverse a String

Concepts:
- String slicing
- Function
- Return value
"""

def reverse_string(text):
    return text[::-1]


if __name__ == "__main__":
    input_text = "python"
    result = reverse_string(input_text)

    print("Input :", input_text)
    print("Output:", result)
