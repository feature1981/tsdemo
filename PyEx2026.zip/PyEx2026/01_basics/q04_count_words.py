"""
Q4. Count Words in a Sentence

split() converts a sentence into list of words.
"""

def count_words(sentence):
    words = sentence.split()
    return len(words)


if __name__ == "__main__":
    sentence = "Python is easy to learn"
    result = count_words(sentence)

    print("Sentence:", sentence)
    print("Word Count:", result)
