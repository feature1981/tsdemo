"""
Q6. Find Smallest Number in a List
"""

def find_smallest(numbers):
    smallest = numbers[0]

    for num in numbers:
        if num < smallest:
            smallest = num

    return smallest


if __name__ == "__main__":
    numbers = [10, 25, 5, 80, 30]
    result = find_smallest(numbers)

    print("Numbers :", numbers)
    print("Smallest:", result)
