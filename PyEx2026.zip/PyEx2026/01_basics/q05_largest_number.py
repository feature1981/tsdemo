"""
Q5. Find Largest Number in a List

Do not use max() initially.
Learn the manual logic first.
"""

def find_largest(numbers):
    largest = numbers[0]

    for num in numbers:
        if num > largest:
            largest = num

    return largest


if __name__ == "__main__":
    numbers = [10, 25, 5, 80, 30]
    result = find_largest(numbers)

    print("Numbers:", numbers)
    print("Largest:", result)
