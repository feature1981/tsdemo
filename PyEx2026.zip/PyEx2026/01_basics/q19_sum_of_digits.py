"""
Q19. Sum of Digits

Example:
1234 = 1 + 2 + 3 + 4 = 10
"""

def sum_of_digits(number):
    total = 0

    for digit in str(abs(number)):
        total += int(digit)

    return total


if __name__ == "__main__":
    number = 1234
    result = sum_of_digits(number)

    print("Number:", number)
    print("Sum of Digits:", result)
