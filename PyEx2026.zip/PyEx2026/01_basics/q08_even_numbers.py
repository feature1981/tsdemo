"""
Q8. Find Even Numbers from a List

A number is even if num % 2 == 0.
"""

def get_even_numbers(numbers):
    even_numbers = []

    for num in numbers:
        if num % 2 == 0:
            even_numbers.append(num)

    return even_numbers


if __name__ == "__main__":
    numbers = [1, 2, 3, 4, 5, 6]
    result = get_even_numbers(numbers)

    print("Numbers:", numbers)
    print("Even Numbers:", result)
