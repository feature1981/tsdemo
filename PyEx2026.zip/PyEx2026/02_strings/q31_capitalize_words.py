"""
Q31. Capitalize First Letter of Every Word
"""

def capitalize_words(sentence):
    return sentence.title()


if __name__ == "__main__":
    sentence = "python automation engineer"

    result = capitalize_words(sentence)

    print("Before:", sentence)
    print("After :", result)
