"""
Q33. Count Special Characters
"""

def count_special_characters(text):
    count = 0

    for char in text:
        if not char.isalnum() and not char.isspace():
            count += 1

    return count


if __name__ == "__main__":
    text = "Python@2026#!"

    result = count_special_characters(text)

    print("Input :", text)
    print("Special Characters:", result)
