"""
Q23. Remove Spaces from String
"""

def remove_spaces(text):
    return text.replace(" ", "")


if __name__ == "__main__":
    text = "Python is easy"

    result = remove_spaces(text)

    print("Before:", text)
    print("After :", result)
