"""
Q36. Find Common Characters Between Two Strings
"""

def common_characters(text1, text2):
    common = set(text1) & set(text2)

    return "".join(sorted(common))


if __name__ == "__main__":
    first = "python"
    second = "typhoon"

    result = common_characters(first, second)

    print("Common Characters:", result)
