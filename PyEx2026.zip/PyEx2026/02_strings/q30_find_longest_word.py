"""
Q30. Find Longest Word in Sentence
"""

def longest_word(sentence):
    words = sentence.split()

    longest = words[0]

    for word in words:
        if len(word) > len(longest):
            longest = word

    return longest


if __name__ == "__main__":
    sentence = "Python automation framework architect"

    result = longest_word(sentence)

    print("Sentence:", sentence)
    print("Longest Word:", result)
