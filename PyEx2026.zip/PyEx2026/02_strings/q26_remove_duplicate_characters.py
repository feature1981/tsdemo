"""
Q26. Remove Duplicate Characters from String
"""

def remove_duplicates(text):
    result = ""

    for char in text:
        if char not in result:
            result += char

    return result


if __name__ == "__main__":
    text = "programming"

    result = remove_duplicates(text)

    print("Input :", text)
    print("Output:", result)
