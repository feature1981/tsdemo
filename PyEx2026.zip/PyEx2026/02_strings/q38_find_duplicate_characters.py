"""
Q38. Find Duplicate Characters
"""

def duplicate_characters(text):
    duplicates = []

    for char in text:
        if text.count(char) > 1 and char not in duplicates:
            duplicates.append(char)

    return duplicates


if __name__ == "__main__":
    text = "programming"

    result = duplicate_characters(text)

    print("Input :", text)
    print("Duplicates:", result)
