"""
Q22. Find First Non-Repeated Character
"""

def first_non_repeated(text):
    for char in text:
        if text.count(char) == 1:
            return char

    return None


if __name__ == "__main__":
    text = "aabbcdde"

    result = first_non_repeated(text)

    print("Input :", text)
    print("Output:", result)
