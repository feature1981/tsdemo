"""
Q24. Count Uppercase and Lowercase Characters
"""

def count_case(text):
    upper = 0
    lower = 0

    for char in text:
        if char.isupper():
            upper += 1
        elif char.islower():
            lower += 1

    return upper, lower


if __name__ == "__main__":
    text = "PyThOn"

    upper, lower = count_case(text)

    print("Uppercase:", upper)
    print("Lowercase:", lower)
