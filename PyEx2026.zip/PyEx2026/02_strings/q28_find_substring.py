"""
Q28. Check if Substring Exists
"""

def substring_exists(main_text, sub_text):
    return sub_text in main_text


if __name__ == "__main__":
    main_text = "Python Automation"
    sub_text = "Auto"

    result = substring_exists(main_text, sub_text)

    print("Substring Exists:", result)
