"""
Q37. Check Palindrome Sentence

Ignore spaces and case sensitivity.
"""

def palindrome_sentence(sentence):
    cleaned = sentence.replace(" ", "").lower()

    return cleaned == cleaned[::-1]


if __name__ == "__main__":
    sentence = "Never odd or even"

    result = palindrome_sentence(sentence)

    print("Palindrome Sentence:", result)
