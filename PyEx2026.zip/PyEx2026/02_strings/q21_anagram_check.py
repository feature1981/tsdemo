"""
Q21. Check Anagram Strings

Two strings are anagrams if characters are same after sorting.
Example:
listen -> silent
"""

def is_anagram(text1, text2):
    return sorted(text1.lower()) == sorted(text2.lower())


if __name__ == "__main__":
    first = "listen"
    second = "silent"

    if is_anagram(first, second):
        print("Anagram")
    else:
        print("Not Anagram")
