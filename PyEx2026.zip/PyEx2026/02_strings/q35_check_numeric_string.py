"""
Q35. Check if String Contains Only Numbers
"""

def is_numeric(text):
    return text.isdigit()


if __name__ == "__main__":
    text = "12345"

    result = is_numeric(text)

    print("Input :", text)
    print("Is Numeric:", result)
