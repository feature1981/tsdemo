"""
Q40. Longest Substring Without Repeating Characters

Interview-important sliding window concept.
"""

def longest_unique_substring(text):
    longest = ""

    for i in range(len(text)):
        seen = ""

        for j in range(i, len(text)):

            if text[j] not in seen:
                seen += text[j]
            else:
                break

        if len(seen) > len(longest):
            longest = seen

    return longest


if __name__ == "__main__":
    text = "abcabcbb"

    result = longest_unique_substring(text)

    print("Input :", text)
    print("Longest Unique Substring:", result)
