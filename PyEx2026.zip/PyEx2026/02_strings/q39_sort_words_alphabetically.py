"""
Q39. Sort Words Alphabetically
"""

def sort_words(sentence):
    words = sentence.split()

    words.sort()

    return words


if __name__ == "__main__":
    sentence = "banana apple mango orange"

    result = sort_words(sentence)

    print("Sorted Words:", result)
