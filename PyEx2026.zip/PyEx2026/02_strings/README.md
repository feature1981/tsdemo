# Python Mastery - 02 Strings

This folder contains intermediate-level string programs.

## Topics Covered

- Anagram
- Compression
- Palindrome
- Sliding Window
- Character Frequency
- Duplicate Handling
- Substring Problems
- String Cleaning
- Pattern Matching

## How to Run

```bash
cd python_mastery/02_strings
python q21_anagram_check.py
```
