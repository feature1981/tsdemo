"""
Q27. String Compression

Example:
aaabbc -> a3b2c1
"""

def compress_string(text):
    compressed = ""
    count = 1

    for i in range(len(text) - 1):

        if text[i] == text[i + 1]:
            count += 1
        else:
            compressed += text[i] + str(count)
            count = 1

    compressed += text[-1] + str(count)

    return compressed


if __name__ == "__main__":
    text = "aaabbc"

    result = compress_string(text)

    print("Input :", text)
    print("Output:", result)
