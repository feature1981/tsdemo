"""
Q32. Check Rotated Strings

Example:
ABCD and CDAB
"""

def is_rotation(text1, text2):
    return len(text1) == len(text2) and text2 in (text1 + text1)


if __name__ == "__main__":
    first = "ABCD"
    second = "CDAB"

    result = is_rotation(first, second)

    print("Rotation:", result)
