"""
Q25. Reverse Each Word in Sentence
"""

def reverse_each_word(sentence):
    words = sentence.split()

    reversed_words = []

    for word in words:
        reversed_words.append(word[::-1])

    return " ".join(reversed_words)


if __name__ == "__main__":
    sentence = "Python is powerful"

    result = reverse_each_word(sentence)

    print("Input :", sentence)
    print("Output:", result)
