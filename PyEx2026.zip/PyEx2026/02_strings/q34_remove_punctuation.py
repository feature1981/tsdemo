"""
Q34. Remove Punctuation from String
"""

import string


def remove_punctuation(text):
    result = ""

    for char in text:
        if char not in string.punctuation:
            result += char

    return result


if __name__ == "__main__":
    text = "Hello, Python!!!"

    result = remove_punctuation(text)

    print("Before:", text)
    print("After :", result)
