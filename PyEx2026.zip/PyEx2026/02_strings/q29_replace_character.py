"""
Q29. Replace Character in String
"""

def replace_character(text, old, new):
    return text.replace(old, new)


if __name__ == "__main__":
    text = "banana"

    result = replace_character(text, "a", "@")

    print("Before:", text)
    print("After :", result)
