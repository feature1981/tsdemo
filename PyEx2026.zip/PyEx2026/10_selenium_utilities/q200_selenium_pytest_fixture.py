"""
Q200. Selenium + PyTest Fixture
"""

import pytest
from selenium import webdriver


@pytest.fixture
def driver():

    driver = webdriver.Chrome()

    yield driver

    driver.quit()


def test_open_page(driver):

    driver.get("https://example.com")

    assert "Example" in driver.title
