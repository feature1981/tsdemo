"""
Q191. File Download Simulation
"""

from selenium import webdriver

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/download")

print("Navigate to download page manually")

driver.quit()
