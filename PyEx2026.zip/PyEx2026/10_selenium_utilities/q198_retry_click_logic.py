"""
Q198. Retry Click Logic
"""

import time
from selenium.common.exceptions import Exception


def retry_click(element, retries=3):

    for attempt in range(retries):

        try:
            element.click()
            return True

        except Exception:

            print(f"Retry Attempt: {attempt + 1}")

            time.sleep(1)

    return False
