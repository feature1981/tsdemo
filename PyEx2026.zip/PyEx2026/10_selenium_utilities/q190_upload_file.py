"""
Q190. Upload File
"""

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/upload")

upload = driver.find_element(By.ID, "file-upload")

upload.send_keys(r"C:\sample.txt")

print("File Uploaded")

driver.quit()
