"""
Q193. Execute JavaScript
"""

from selenium import webdriver

driver = webdriver.Chrome()

driver.get("https://example.com")

title = driver.execute_script("return document.title;")

print(title)

driver.quit()
