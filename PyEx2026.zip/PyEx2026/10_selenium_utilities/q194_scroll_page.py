"""
Q194. Scroll Web Page
"""

from selenium import webdriver

driver = webdriver.Chrome()

driver.get("https://example.com")

driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

print("Page Scrolled")

driver.quit()
