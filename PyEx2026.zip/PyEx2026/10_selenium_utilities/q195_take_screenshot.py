"""
Q195. Take Screenshot
"""

from selenium import webdriver

driver = webdriver.Chrome()

driver.get("https://example.com")

driver.save_screenshot("homepage.png")

print("Screenshot Saved")

driver.quit()
