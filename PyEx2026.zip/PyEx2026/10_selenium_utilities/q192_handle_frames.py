"""
Q192. Handle Frames
"""

from selenium import webdriver

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/iframe")

driver.switch_to.frame("mce_0_ifr")

print("Inside Frame")

driver.quit()
