"""
Q185. Enter Text in Input Field
"""

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/login")

username = driver.find_element(By.ID, "username")

username.send_keys("admin")

print("Text Entered")

driver.quit()
