"""
Q189. Handle Multiple Windows
"""

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/windows")

driver.find_element(By.LINK_TEXT, "Click Here").click()

windows = driver.window_handles

driver.switch_to.window(windows[1])

print(driver.title)

driver.quit()
