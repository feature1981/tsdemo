# Python Mastery - 10 Selenium Utilities

This folder contains Selenium automation utility examples.

## Install Dependencies

```bash
pip install -r requirements.txt
```

## Topics Covered

- Browser launch
- Element locators
- XPath
- Explicit wait
- Alerts
- Dropdowns
- Frames
- Multiple windows
- JavaScript execution
- Screenshots
- Headless execution
- Retry logic
- Wait utilities
- Selenium + PyTest

## Run Example

```bash
python q181_launch_browser.py
```
