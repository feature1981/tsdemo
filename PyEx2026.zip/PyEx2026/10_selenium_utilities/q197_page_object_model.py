"""
Q197. Simple Page Object Model
"""

from selenium.webdriver.common.by import By


class LoginPage:

    USERNAME = (By.ID, "username")

    def __init__(self, driver):
        self.driver = driver

    def enter_username(self, username):

        self.driver.find_element(*self.USERNAME).send_keys(username)
