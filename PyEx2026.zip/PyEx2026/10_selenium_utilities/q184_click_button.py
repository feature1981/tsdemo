"""
Q184. Click Button
"""

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/add_remove_elements/")

button = driver.find_element(By.XPATH, "//button[text()='Add Element']")

button.click()

print("Button Clicked")

driver.quit()
