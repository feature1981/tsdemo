"""
Q181. Launch Chrome Browser

Prerequisite:
pip install selenium
"""

from selenium import webdriver


driver = webdriver.Chrome()

driver.get("https://example.com")

print(driver.title)

driver.quit()
