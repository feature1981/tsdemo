"""
Q186. Explicit Wait Example
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()

driver.get("https://the-internet.herokuapp.com/dynamic_loading/1")

wait = WebDriverWait(driver, 10)

element = wait.until(
    EC.presence_of_element_located((By.TAG_NAME, "body"))
)

print("Page Loaded")

driver.quit()
