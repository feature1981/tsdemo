def balancedParentheses():
    s = "({[]})"

    print("Input:", s)

    stack = []
    pairs = {')': '(', '}': '{', ']': '['}

    for c in s:
        if c in "([{":
            stack.append(c)
        else:
            if not stack or stack[-1] != pairs[c]:
                print("Balanced:", False)
                return
            stack.pop()

    print("Balanced:", len(stack) == 0)


if __name__ == "__main__":
    balancedParentheses()