def subarraySumK():
    arr = [1, 2, 3]
    k = 3

    print("Input:", arr)
    print("Target Sum:", k)

    subarrcount = 0
    prefix = {0: 1}
    sumOfArray = 0

    for x in arr:
        sumOfArray += x

        if sumOfArray - k in prefix:
            subarrcount += prefix[sumOfArray - k]

        prefix[sumOfArray] = prefix.get(sumOfArray, 0) + 1

    print("Subarrays Count:", subarrcount)

if __name__ == "__main__":
    subarraySumK()
    