def intersectionArrays():
    a = [1, 2, 2, 3, 4]
    b = [2, 2, 4, 6]

    print("Array A:", a)
    print("Array B:", b)
    print("set a:", set(a))
    print("set b:", set(b))
    result = list(set(a) & set(b))

    print("Intersection:", result)

if __name__ == "__main__":
    intersectionArrays()