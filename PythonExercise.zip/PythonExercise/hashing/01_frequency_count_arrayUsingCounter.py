from collections import Counter

def frequencyArray():
    arr = [1, 2, 2, 3, 1, 4, 2]
    print("Input:", arr)
    freq = Counter(arr)
    print("Frequency:", freq)

if __name__ == "__main__":
    frequencyArray()