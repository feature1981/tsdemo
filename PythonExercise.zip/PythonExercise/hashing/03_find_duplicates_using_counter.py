from collections import Counter

def findDuplicates():
    arr = [1, 2, 3, 2, 4, 1, 5]
    print("Input:", arr)
    freq = Counter(arr)
    result = [x for x in freq if freq[x] > 1]
    print("Duplicates:", result)

if __name__ == "__main__":
    findDuplicates()