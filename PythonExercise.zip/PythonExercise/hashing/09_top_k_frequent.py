from collections import Counter

def topKFrequent():
    arr = [1,1,1,2,2,3,3,4]
    k=2
    print("Input",arr)
    print("K",k)
    freq = Counter(arr)
    result = [x for x, _ in freq.most_common(k)]
    print("Top K Frequent:", result)

if __name__ == "__main__":
    topKFrequent()

