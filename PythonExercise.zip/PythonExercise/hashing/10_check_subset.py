def checksubset():
    a = [1,2]
    b = [1,2,3,4]
    print("A:",a)
    print("B:",b)
    result = set(a).issubset(set(b))
    print("Is Subset",result)

if __name__== "__main__":
    checksubset()