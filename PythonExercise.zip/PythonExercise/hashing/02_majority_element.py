from collections import Counter

def majorityElement():
    arr = [1,2, 2, 1, 3, 5, 3,3]

    print("Input:", arr)

    freq = Counter(arr)
    print("freq",freq)
    result = max(freq, key=freq.get)
    # result = max(freq)

    print("Majority Element:", result)

if __name__ == "__main__":
    majorityElement()

# Count frequency of elements
# Element with highest count → majority
# max(..., key=freq.get) picks max frequency