from collections import Counter

def firstUniqueArray():
    arr = [4, 5, 1, 2, 0, 4, 1, 2]
    print("Input:", arr)
    freq = Counter(arr)
    print("freq=",freq)
    for x in arr:
        if freq[x] == 1:
            print("First Unique:", x)
            return
    print("No Unique Element")

if __name__ == "__main__":
    firstUniqueArray()