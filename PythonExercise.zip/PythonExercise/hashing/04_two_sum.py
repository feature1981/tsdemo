def twoSum():
    arr = [2,11,13,12, 7, 11, 15]
    target = 9
    print("Input:", arr)
    print("Target:", target)
    seen = set()
    
    for x in arr:
        print("\nCurrent:", x)
        print("Need:", target - x)
        print("Seen:", seen)
        if target - x in seen:
            print("target - x",target - x)
            print("Pair Found:", (x, target - x))
            return
        seen.add(x)
        print("seen after check",seen)

    print("No Pair Found")

if __name__ == "__main__":
    twoSum()