def frequencyArray():
    arr = [1, 2, 2, 3, 1, 4, 2]

    print("Input:", arr)

    freq = {} # dict

    for x in arr:
        freq[x] = freq.get(x, 0) + 1
        print(x, freq[x])

    print("Frequency:", freq)


if __name__ == "__main__":
    frequencyArray()