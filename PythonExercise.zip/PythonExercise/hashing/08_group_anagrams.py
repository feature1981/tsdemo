from collections import defaultdict

def groupAnagrams():
    strs = ["eat", "tea", "tan", "ate", "nat", "bat","ram","arm","del","led"]

    print("Input:", strs)

    groups = defaultdict(list)
    print("groups",groups.values())

    for word in strs:
        key = "".join(sorted(word))
        print("\nword=",word)
        print("key=",key)
        groups[key].append(word)
        print("group value = ",groups.values())

    print("\nGrouped Anagrams:", list(groups.values()))

if __name__ == "__main__":
    groupAnagrams()