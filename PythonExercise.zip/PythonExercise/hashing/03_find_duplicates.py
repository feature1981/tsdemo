def findDuplicates():
    arr = [1, 2, 3, 2, 4, 1, 5]

    print("Input:", arr)

    freq = {}

    for x in arr:
        freq[x] = freq.get(x, 0) + 1

    result = [x for x in freq if freq[x] > 1]

    print("Duplicates:", result)


if __name__ == "__main__":
    findDuplicates()


#Count frequency using dictionary
# Elements with count > 1 → duplicates
# Simple hashing approach