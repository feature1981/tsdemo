def longestOnes():
    arr = [1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0]
    k = 2

    print("Input:", arr)
    print("K:", k)

    l = 0
    zero_count = 0
    max_len = 0

    for r in range(len(arr)):
        if arr[r] == 0:
            zero_count += 1

        while zero_count > k:
            if arr[l] == 0:
                zero_count -= 1
            l += 1

        max_len = max(max_len, r - l + 1)

    print("Longest Length:", max_len)


if __name__ == "__main__":
    longestOnes()