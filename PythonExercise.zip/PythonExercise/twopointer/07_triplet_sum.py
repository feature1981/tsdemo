def tripletSum():
    arr = [-1, 0, 1, 2, -1, -4]
    target = 0

    print("Input:", arr)

    arr.sort()
    result = []

    for i in range(len(arr) - 2):
        if i > 0 and arr[i] == arr[i - 1]:
            continue   # skip duplicates

        l = i + 1
        r = len(arr) - 1

        while l < r:
            curr = arr[i] + arr[l] + arr[r]

            if curr == target:
                result.append([arr[i], arr[l], arr[r]])
                l += 1
                r -= 1

                while l < r and arr[l] == arr[l - 1]:
                    l += 1
                while l < r and arr[r] == arr[r + 1]:
                    r -= 1

            elif curr < target:
                l += 1
            else:
                r -= 1

    print("Triplets:", result)


if __name__ == "__main__":
    tripletSum()