def removeduplicates():
    arr = [1,1,1,2,3,2,3,4,5,6]
    arr.sort()
    i = 0
    print("arr=",arr)
    for j in range(1, len(arr)):
        print("\ni=",i,", j=",j,"arr[i]=",arr[i],"arr[j]=",arr[j])
        if arr[j]!=arr[i]:
            i += 1
            arr[i] = arr[j]
            print("i=",i,", j=",j,"arr[i]=",arr[i],"arr[j]=",arr[j])
            print(arr)
    print("Output:",arr[:i+1])

if __name__=="__main__":
    removeduplicates()
