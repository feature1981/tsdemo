def sortedSquares():
    arr = [-4, -1, 0, 3, 10]

    print("Input:", arr)

    l, r = 0, len(arr) - 1
    result = [0] * len(arr)
    pos = len(arr) - 1

    while l <= r:
        if abs(arr[l]) > abs(arr[r]):
            result[pos] = arr[l] * arr[l]
            l += 1
        else:
            result[pos] = arr[r] * arr[r]
            r -= 1

        pos -= 1

    print("Output:", result)


if __name__ == "__main__":
    sortedSquares()