def maxWindowSum():
    arr = [9,8,7,6,5,4,3,2,1]
    k = 3

    print("Input:", arr)
    print("Window Size:", k)
    print(len(arr))
    window = sum(arr[:k])
    print(arr[:k])
    max_sum = window

    for i in range(k, len(arr)):
        print("k=",k,"i=",i,"window=",window,"arr[i]",arr[i], "arr[i - k]",arr[i - k],"max_sum=",max_sum)
        window = window + arr[i] - arr[i - k]
        max_sum = max(max_sum, window)
        print("window=",window,"max_sum=",max_sum)

    print("Max Window Sum:", max_sum)

if __name__ == "__main__":
    maxWindowSum()