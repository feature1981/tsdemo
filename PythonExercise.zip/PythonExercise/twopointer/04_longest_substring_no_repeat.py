def longestSubstring():
    s = "abcabcbb"
    print("range(len(s))=",range(len(s)))
    print("Input:", s)
    seen = set()
    l = 0
    max_len = 0

    for r in range(len(s)):
        while s[r] in seen:
            print("seen before remove=",seen)
            seen.remove(s[l])
            print("seen after remove=",seen)
            l += 1

        seen.add(s[r])
        max_len = max(max_len, r - l + 1)
        print("r=",r,", s[r]=",s[r],", ")

    print("Longest Length:", max_len)

if __name__ == "__main__":
    longestSubstring()