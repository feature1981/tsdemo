def containerWater():
    arr = [1, 8, 6, 2, 5, 4, 8, 3, 7]

    print("Input:", arr)

    l = 0
    r = len(arr) - 1
    max_area = 0

    while l < r:
        height = min(arr[l], arr[r])
        width = r - l
        area = height * width

        max_area = max(max_area, area)

        if arr[l] < arr[r]:
            l += 1
        else:
            r -= 1

    print("Max Area:", max_area)


if __name__ == "__main__":
    containerWater()