def longestSubstring():
    s = "abcabcbb"

    seen = set()
    l = 0
    max_len = 0
    start = 0   # track best start

    for r in range(len(s)):
        while s[r] in seen:
            seen.remove(s[l])
            l += 1

        seen.add(s[r])

        if r - l + 1 > max_len:
            max_len = r - l + 1
            start = l   # update start index

    print("Length:", max_len)
    print("Substring:", s[start:start + max_len])


if __name__ == "__main__":
    longestSubstring()