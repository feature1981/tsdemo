def minWindowSum():
    arr = [2, 1, 5, 2, 3, 2]
    k = 7

    print("Input:", arr)
    print("Target Sum:", k)

    l = 0
    curr = 0
    min_len = float('inf')

    for r in range(len(arr)):
        curr += arr[r]

        while curr >= k:
            min_len = min(min_len, r - l + 1)
            curr -= arr[l]
            l += 1

    print("Min Length:", min_len if min_len != float('inf') else 0)


if __name__ == "__main__":
    minWindowSum()