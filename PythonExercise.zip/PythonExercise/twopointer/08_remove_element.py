def removeElement():
    arr = [3, 2, 2, 3]
    val = 3

    print("Input:", arr)
    print("Remove:", val)

    result = [x for x in arr if x != val]

    print("Output:", result)


if __name__ == "__main__":
    removeElement()