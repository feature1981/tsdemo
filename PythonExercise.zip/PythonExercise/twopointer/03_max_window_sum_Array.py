def maxWindowSum():
    arr = [9,8,7,6,5,4,3,2,1]
    k = 3

    print("Input:", arr)
    print("Window Size:", k)
    print(len(arr))
    window = sum(arr[:k])
    print(arr[:k])
    max_sum = window
    start = 0   # track best window start

    for i in range(k, len(arr)):
        print("k=",k,"i=",i,"window=",window,"arr[i]",arr[i], "arr[i - k]",arr[i - k],"max_sum=",max_sum)
        window = window + arr[i] - arr[i - k]
        if window > max_sum:
            max_sum = window
            start = i - k + 1   #update start index
    
    print("Max Window Sum:", max_sum)
    print("subarray:",arr[start:start+k])

if __name__ == "__main__":
    maxWindowSum()