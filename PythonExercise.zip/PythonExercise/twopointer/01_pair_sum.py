def pairsum():
    arr=[1,2,3,6,8,3,7]
    target = 6
    print("input = ",arr)
    print("target = ",target)
    l,r=0,len(arr)-1
    while l < r:
        curr = arr[l]+arr[r]
        print("\ncurr=",curr,", l=",l,", r=",r)
        if curr == target:
            print("Pair Found:",(arr[l],arr[r]))
            return
        elif curr < target:
            l += 1
        else:
            r -= 1
    print("Pair not found")

if __name__=="__main__":
    pairsum()

