# def countVowels():
#     s = "Murugan"
#     print("Input:", s)
#     count = sum(1 for c in s.lower() if c in "aeiou")
#     print("Vowel Count:", count)

def countVowels():
    s = "Murugan"
    vowels = "aeiou"
    count = 0
    for c in s.lower():
        if c in vowels:
            count += 1
    print("Vowel Count:", count)

if __name__ == "__main__":
    countVowels()