def longestWord():
    s = "I love learning Python programming"

    print("Input:", s)
    print("AfterSplit",s.split())
    result = max(s.split(), key=len)

    print("Longest Word:", result)

if __name__ == "__main__":
    longestWord()