def checkPalindrome():
    s = "madam"

    print("Input:", s)

    result = s == s[::-1]

    print("Is Palindrome:", result)


if __name__ == "__main__":
    checkPalindrome()