def countWords():
    s = "I love Python programming"

    print("Input:", s)

    result = len(s.split())

    print("Word Count:", result)


if __name__ == "__main__":
    countWords()