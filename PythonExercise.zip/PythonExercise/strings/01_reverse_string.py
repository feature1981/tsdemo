def reverseString():
    s = "Murugan"

    print("Input:", s)

    result = s[::-1]

    print("Reversed:", result)


if __name__ == "__main__":
    reverseString()