from collections import Counter

def firstUnique():
    s = "waswiss"
    print("Input:", s)
    freq = Counter(s)
    print("freq",freq)

    for c in s:
        if freq[c] == 1:
            print("First Unique:", c)
            return

    print("No unique character")

if __name__ == "__main__":
    firstUnique()
    