def removeDuplicates():
    s = "programming"

    print("Input:", s)

    result = "".join(set(s))

    print("Output:", result)


if __name__ == "__main__":
    removeDuplicates()