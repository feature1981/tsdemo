from collections import Counter

def frequencyCount():
    s = "programming"

    print("Input:", s)

    freq = Counter(s)

    print("Frequency:", freq)


if __name__ == "__main__":
    frequencyCount()