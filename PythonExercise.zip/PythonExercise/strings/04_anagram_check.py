from collections import Counter

def checkAnagram():
    s1 = "listen"
    s2 = "silent"

    print("Input:", s1, s2)
    print(sorted(s1))
    print(sorted(s2))
    result = sorted(s1) == sorted(s2)

    print("Is Anagram:", result)

def checkAnagram1():
    s1 = "listen"
    s2 = "silent"

    print("Input:", s1, s2)
    print(Counter(s1))
    print(Counter(s2))
    result = Counter(s1) == Counter(s2)
    print("Is Anagram:", result)

if __name__ == "__main__":
    checkAnagram1()