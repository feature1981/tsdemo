def capitalizeWords():
    s = "i love python programming"

    print("Input:", s)

    result = s.title()

    print("Output:", result)


if __name__ == "__main__":
    capitalizeWords()