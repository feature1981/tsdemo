def removeDuplicates():
    s = "programming"
    seen = set()
    result = ""
    for c in s:
        if c not in seen:
            result += c
            seen.add(c)
            print(result)
    print("Output:", result)

if __name__ == "__main__":
    removeDuplicates()
    