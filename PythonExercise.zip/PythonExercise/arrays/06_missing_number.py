def findMissing():
    arr = [1, 2, 3, 5]   # 4 is missing

    print("Input:", arr)

    n = len(arr) + 1

    print("length of array = n=",n)
    print("n*(n+1)//2 = ",n*(n+1)//2)
    print("original array total = ",n*(n+1)//2)
    result = n * (n + 1) // 2 - sum(arr)

    print("Missing Number:", result)

if __name__ == "__main__":
    findMissing()
    