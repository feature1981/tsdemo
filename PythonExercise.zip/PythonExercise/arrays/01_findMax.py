def solve():
    arr = [10, 20, 5, 99, 3]
    print("Input:", arr)

    result = max(arr)

    print("Output:", result)

if __name__ == "__main__":
    solve()