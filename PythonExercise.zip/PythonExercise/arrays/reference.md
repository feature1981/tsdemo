1. Python Operator Precedence (relevant here)

From highest → lowest (only what matters here):

() → Parentheses
*, /, //, % → Multiplication / Division
+, - → Addition / Subtraction

👉 Important:

* and // have same precedence
Evaluation is LEFT → RIGHT for same precedence operators