def checkSorted():
    arr = [7,1, 2, 3, 4, 5]

    print("Input:", arr)

    result = arr == sorted(arr)

    print("Is Sorted:", result)


if __name__ == "__main__":
    checkSorted()