def kadaneDebug():
    arr = [7, 1, -3, 4, -1, 2, 1,-3,2,1]
    curr = arr[0]
    max_sum = arr[0]

    print(" Element  Curr   Max")

    for x in arr[1:]:
        curr = max(x, curr + x)
        max_sum = max(max_sum, curr)

        print("   ",x, "   ", curr, "   ", max_sum)

if __name__ == "__main__":
    kadaneDebug()