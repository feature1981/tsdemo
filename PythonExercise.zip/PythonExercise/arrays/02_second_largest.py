def solve():
    arr = [10, 45, 45, 2, 99, 23]
    print("Input:", arr)
    print("set(arr):",set(arr)) # set removes the duplicate record. - Python set is unordered.
    unique_arr = list(set(arr)) # Converts the set back into the list format - list 
    print("unique_arr:",unique_arr)
    unique_arr.sort()
    print("sorted Array : ",unique_arr)
    result = unique_arr[-2]
    print("Second largest:", result)

if __name__ == "__main__":
    solve()