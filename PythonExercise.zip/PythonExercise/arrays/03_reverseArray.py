def reserveArray():
    arr = [12, 20, 15, 9, 8,11,3,25,12]
    print("Input:", arr)
    result = arr[::-1]
    print("Output:", result)

if __name__ == "__main__":
    reserveArray()