# Move zeros in the array to the end
def moveZeros():
    arr = [0, 1, 0, 3, 12]
    print("Input:", arr)
    res = [x for x in arr if x != 0] + [0]*arr.count(0)
    print("Output:", res)

if __name__ == "__main__":
    moveZeros()