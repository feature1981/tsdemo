def mergeArrays():
    arr1 = [1, 3, 5]
    arr2 = [2, 4, 6]

    print("Array1:", arr1)
    print("Array2:", arr2)
    result = arr1+arr2
    print(result)
    result = sorted(arr1 + arr2)

    print("Merged:", result)


if __name__ == "__main__":
    mergeArrays()