def rotateLeft():
    arr = [10, 20, 30, 40, 50]
    d = 2

    print("Input:", arr)
    print("Rotate by:", d)
    #arr[d:] --> Elements from d to the end. arr[:d] --> Elements from start to d.
    print("arr[d:]=",arr[d:],", arr[:d]=",arr[:d])
    result = arr[d:] + arr[:d]
    
    print("Rotate Left Output:", result)

def rotateRight():
    arr1 = [1, 2, 3, 4, 5]
    d = 2

    print("Input:", arr1)
    print("Rotate by:", d)
    print("arr1[-d:]=",arr1[-d:],", arr1[:-d]=",arr1[:-d])
    result1 = arr1[-d:] + arr1[:-d]

    print("Rotate Right Output:", result1)

if __name__ == "__main__":
    rotateLeft()
    rotateRight()
    