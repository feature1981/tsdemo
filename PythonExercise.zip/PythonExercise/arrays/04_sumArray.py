def sumArray():
    arr = [12, 20, 15, 9, 8, 11, 3, 25, 12]
    print("Input:", arr)

    result = sum(arr)

    print("Sum:", result)

if __name__ == "__main__":
    sumArray()
